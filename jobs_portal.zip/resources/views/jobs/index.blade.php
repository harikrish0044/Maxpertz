@extends('layouts.app');

@section('content')
    <div class="pull-right">
        <a href="{{route('jobs.create')}}" class="btn btn-primary">Create New jobs</a>
    </div>
    @if(empty($jobs))
        <p>New Jobs is created</p>
    @else
        <div class="row">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Category</th>
                        <th>Created At</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($jobs as $job)
                    <tr>
                        <td>
                            <h3>{{ $job->title }}</h3>
                            <p>{{ $job->description }}</p>
                        </td>
                        <td><strong>{{ $job->category }}</strong></td>
                        <td><i>{{ $job->created_at->format('Y-m-d') }}</i></td>
                        <td>
                            <div class="pull-left">
                                <a class="btn btn-default btn-sm" href="{{route('jobs.edit', $job->id)}}">Edit</a>
                            </div>
                            <div class="pull-left">
                                {!! Form::open(['method' => 'delete', 'route' => ['jobs.destroy', $job->id]]) !!}
                                    {!! Form::submit('Delete', ['class'=>'btn btn-danger btn-sm']) !!}
                                {!! Form::close() !!}
                            </div>
                        </td>
                    </tr>
                     @endforeach
                </tbody>
            </table>
            
            
            
            <div class="col-xs-12">
                
                <br>
                
                
            </div>  
            

       
        </div>
    @endif
@endsection