@extends('layouts.app')

@section('content')
<div class="container">
    <h2>{{$job->title}}</h2>
    <p><strong>Job Type : </strong><i>{{$job->category}}</i></p>
    <p><strong>Created At : </strong><date>{{$job->created_at->format('Y-m-d')}}</date></p>
    
    <p>{{$job->description}}</p>
</div>
@endsection
