<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Welcome to homepage</h1>
    <h2>List of jobs</h2>
    
    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
            <h4><a href="<?php echo e(route('jobs.show', $job->id)); ?>"><?php echo e($job->title); ?></a></h4>
            <p><?php echo e($job->description); ?></p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>