;

<?php $__env->startSection('content'); ?>
    <div class="pull-right">
        <a href="<?php echo e(route('jobs.create')); ?>" class="btn btn-primary">Create New jobs</a>
    </div>
    <?php if(empty($jobs)): ?>
        <p>New Jobs is created</p>
    <?php else: ?>
        <div class="row">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Category</th>
                        <th>Created At</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <h3><?php echo e($job->title); ?></h3>
                            <p><?php echo e($job->description); ?></p>
                        </td>
                        <td><strong><?php echo e($job->category); ?></strong></td>
                        <td><i><?php echo e($job->created_at->format('Y-m-d')); ?></i></td>
                        <td>
                            <div class="pull-left">
                                <a class="btn btn-default btn-sm" href="<?php echo e(route('jobs.edit', $job->id)); ?>">Edit</a>
                            </div>
                            <div class="pull-left">
                                <?php echo Form::open(['method' => 'delete', 'route' => ['jobs.destroy', $job->id]]); ?>

                                    <?php echo Form::submit('Delete', ['class'=>'btn btn-danger btn-sm']); ?>

                                <?php echo Form::close(); ?>

                            </div>
                        </td>
                    </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            
            
            
            <div class="col-xs-12">
                
                <br>
                
                
            </div>  
            

       
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>